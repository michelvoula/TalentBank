package beans;
/*
 * enumeration of available value in the config entity
 */
public enum Parameters {
accept_message,
accept_message_Title,
reject_message,
reject_message_Title,
}
